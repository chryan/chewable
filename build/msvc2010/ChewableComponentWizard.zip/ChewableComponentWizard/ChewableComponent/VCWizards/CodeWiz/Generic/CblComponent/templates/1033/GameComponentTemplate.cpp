/** @file [!output CLASS_NAME].cpp
 *  @author [!output USER_NAME]
 *  @date [!output DATE_TIME]
 *  
 *  Description here.
 */

#include "[!output CLASS_NAME].h"

using namespace [!output PROJECT_NAME];

[!if COMPONENT_TYPE == "Object"]
CBL_REGISTER_OBJECT( [!output CLASS_NAME] );

[!output CLASS_NAME]::[!output CLASS_NAME]()
{
}

[!output CLASS_NAME]::~[!output CLASS_NAME]()
{
}

void [!output CLASS_NAME]::Initialise( void )
{
}

void [!output CLASS_NAME]::Shutdown( void )
{
}

void [!output CLASS_NAME]::Serialise( const cbl::FileInfo & file ) const
{
}

void [!output CLASS_NAME]::Deserialise( const cbl::FileInfo & file )
{
}
[!endif]
[!if COMPONENT_TYPE == "ObjectComponent" ]
CBL_REGISTER_OBJECT_COMPONENT( [!output CLASS_NAME] );

[!output CLASS_NAME]::[!output CLASS_NAME]( cbl::Object & object )
: cbl::[!output COMPONENT_TYPE]( object )
{
}

[!output CLASS_NAME]::~[!output CLASS_NAME]()
{
}

void [!output CLASS_NAME]::Initialise( void )
{
}

void [!output CLASS_NAME]::Shutdown( void )
{
}

void [!output CLASS_NAME]::Serialise( const cbl::FileInfo & file ) const
{
}

void [!output CLASS_NAME]::Deserialise( const cbl::FileInfo & file )
{
}
[!endif]
[!if COMPONENT_TYPE == "GameComponent" ]
[!output CLASS_NAME]::[!output CLASS_NAME]( cbl::Game & game )
: cbl::[!output COMPONENT_TYPE]( game )
{
}

[!output CLASS_NAME]::~[!output CLASS_NAME]()
{
}

void [!output CLASS_NAME]::Initialise( void )
{
}

void [!output CLASS_NAME]::Shutdown( void )
{
}

void [!output CLASS_NAME]::Update( const cbl::GameTime & time )
{
}
[!endif]
[!if COMPONENT_TYPE == "DrawableGameComponent" ]
[!output CLASS_NAME]::[!output CLASS_NAME]( cbl::Game & game )
: cbl::[!output COMPONENT_TYPE]( game )
{
}

[!output CLASS_NAME]::~[!output CLASS_NAME]()
{
}

void [!output CLASS_NAME]::Initialise( void )
{
}

void [!output CLASS_NAME]::Shutdown( void )
{
}

void [!output CLASS_NAME]::Update( const cbl::GameTime & time )
{
}

void [!output CLASS_NAME]::Draw( const cbl::GameTime & time )
{
}
[!endif]
[!if COMPONENT_TYPE == "GameState"]
[!output CLASS_NAME]::[!output CLASS_NAME]()
{
}

[!output CLASS_NAME]::~[!output CLASS_NAME]()
{
}

void [!output CLASS_NAME]::Activate( void )
{
}

void [!output CLASS_NAME]::Deactivate( void )
{
}

void [!output CLASS_NAME]::Resume( void )
{
}

void [!output CLASS_NAME]::Pause( void )
{
}
[!endif]