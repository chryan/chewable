/** @file [!output CLASS_NAME].h
 *  @author [!output USER_NAME]
 *  @date [!output DATE_TIME]
 *  
 *  [!output CLASS_NAME].
 */
 
#ifndef __[!output CAPS_PROJECT_NAME]_[!output CAPS_CLASS_NAME]_H_
#define __[!output CAPS_PROJECT_NAME]_[!output CAPS_CLASS_NAME]_H_

// Chewable Headers //
#include "cbl/Chewable.h"
#include "cbl/Core/[!output COMPONENT_TYPE].h"
[!if COMPONENT_TYPE == "Object"]
#include "cbl/Core/ObjectRegistry.h"
#include "cbl/Util/Type.h"
[!endif]
[!if COMPONENT_TYPE == "ObjectComponent"]
#include "cbl/Core/ObjectRegistry.h"
#include "cbl/Util/Type.h"
[!endif]
[!if COMPONENT_TYPE == "GameState"]
#include "cbl/Core/ObjectRegistry.h"
#include "cbl/Util/Type.h"
[!endif]

namespace [!output PROJECT_NAME]
{
	//! @TODO [!output CLASS_NAME]
	class [!output CLASS_NAME] :
		public cbl::[!output COMPONENT_TYPE]
	{
[!if COMPONENT_TYPE == "Object"]
	/***** Public Methods *****/
	public:
		//! Destructor.
		virtual ~[!output CLASS_NAME]();
		//! Serialise object to file.
		virtual void Serialise( const cbl::FileInfo & file ) const;
		//! Deserialise object from file.
		virtual void Deserialise( const cbl::FileInfo & file );

	/***** Protected Methods *****/
	protected:
		//! Constructor.
		[!output CLASS_NAME]();
		//! Initialise object.
		virtual void Initialise( void );
		//! Shutdown object.
		virtual void Shutdown( void );
	
	/***** Private Members *****/
	private:
		template< typename T >
		friend class	SharedPtr;			//!< Befriend the shared ptr type.
		template< typename T >
		friend class	WeakPtr;			//!< Befriend the weak ptr type.
		//! Become friends!
		CBL_OBJECT_FRIENDS;
[!endif]
[!if COMPONENT_TYPE == "ObjectComponent"]
	/***** Public Methods *****/
	public:
		//! Destructor.
		virtual ~[!output CLASS_NAME]();
		//! Serialise object component to file.
		virtual void Serialise( const cbl::FileInfo & file ) const;
		//! Deserialise object component from file.
		virtual void Deserialise( const cbl::FileInfo & file );

	/***** Protected Methods *****/
	protected:
		//! Constructor.
		[!output CLASS_NAME]( cbl::Object & object );
		//! Initialise object component.
		virtual void Initialise( void );
		//! Shutdown object component.
		virtual void Shutdown( void );
		//! Become friends!
		CBL_OBJECT_COMPONENT_FRIENDS;
[!endif]
[!if COMPONENT_TYPE == "GameComponent" ]
	/***** Public Methods *****/
	public:
		//! Explicit constructor.
		//! @param	game	Game pointer.
		explicit [!output CLASS_NAME]( cbl::Game & game );
		//! Destructor.
		virtual ~[!output CLASS_NAME]();
		//! Abstract function to initialise component (from GameComponent).
		virtual void Initialise( void );
		//! Abstract function to shut down component (from GameComponent).
		virtual void Shutdown( void );
		//! Pure virtual update function (from IUpdatable).
		virtual void Update( const cbl::GameTime & time );
[!endif]
[!if COMPONENT_TYPE == "DrawableGameComponent" ]
	/***** Public Methods *****/
	public:
		//! Explicit constructor.
		//! @param	game	Game pointer.
		explicit [!output CLASS_NAME]( cbl::Game & game );
		//! Destructor.
		virtual ~[!output CLASS_NAME]();
		//! Abstract function to initialise component (from GameComponent).
		virtual void Initialise( void );
		//! Abstract function to shut down component (from GameComponent).
		virtual void Shutdown( void );
		//! Pure virtual update function (from IUpdatable).
		virtual void Update( const cbl::GameTime & time );
		//! Pure virtual update function (from IDrawable).
		virtual void Draw( const cbl::GameTime & time );
[!endif]
[!if COMPONENT_TYPE == "GameState" ]
	/***** Public Methods *****/
	public:
		//! Constructor.
		[!output CLASS_NAME]();
		//! Destructor.
		virtual ~[!output CLASS_NAME]();
		//! Called when state is added/pushed.
		virtual void Activate( void );
		//! Called when state is removed/popped.
		virtual void Deactivate( void );
		//! Called when a state is popped from the stack and this state is the new state on top.
		virtual void Resume( void );
		//! Called when a state is pushed on to the stack and was the previous state on top.
		virtual void Pause( void );
[!endif]
	};
}
[!if COMPONENT_TYPE == "Object"]

CBL_DECL_TYPE( [!output PROJECT_NAME]::[!output CLASS_NAME], [!output CLASS_NAME] );

[!endif]
[!if COMPONENT_TYPE == "ObjectComponent"]

CBL_DECL_TYPE( [!output PROJECT_NAME]::[!output CLASS_NAME], [!output CLASS_NAME] );

[!endif]

#endif // __[!output CAPS_PROJECT_NAME]_[!output CAPS_CLASS_NAME]_H_
